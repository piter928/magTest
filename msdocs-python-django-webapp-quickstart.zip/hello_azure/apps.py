from django.apps import AppConfig


class HelloAzureConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hello_azure'
